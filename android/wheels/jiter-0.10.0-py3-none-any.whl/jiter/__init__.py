"""``jiter`` yerine geçen saf Python paketi (Android için).

Neden var: openai SDK 2.x tek bir yerde jiter kullanıyor —
``openai/lib/streaming/chat/_completions.py``:

    from jiter import from_json

Gerçek jiter bir Rust ayrıştırıcısı ve Android yapısı yok. Yaptığı iş
"JSON metnini Python nesnesine çevir"; ``json`` modülü de bunu yapıyor.
Hızı daha düşük ama akış ayrıştırması ağ hızının yanında önemsiz kalıyor.

Kısmi (yarım) JSON desteği ``partial_mode`` ile geliyor: gerçek jiter
tamamlanmamış girdiyi elinden geldiğince ayrıştırıyor. Burada tamamlanmamış
girdi için boş sözlük dönüyoruz — openai SDK'sı zaten her parçada yeniden
deniyor ve tam parçada doğru sonucu alıyor.
"""

from __future__ import annotations

import json
from typing import Any

__version__ = "0.10.0"
__all__ = ["from_json", "LosslessFloat"]


class LosslessFloat(float):
    """Gerçek jiter'in ondalık kaybını önleyen tipi; burada metni saklıyoruz."""

    def __new__(cls, value: str | float):
        instance = super().__new__(cls, float(value))
        instance._raw = str(value)
        return instance

    def as_decimal(self):
        from decimal import Decimal

        return Decimal(self._raw)

    def __repr__(self) -> str:
        return self._raw

    def __str__(self) -> str:
        return self._raw


def from_json(
    data: bytes | bytearray | memoryview | str,
    /,
    *,
    allow_inf_nan: bool = True,
    cache_mode: Any = "all",
    partial_mode: Any = False,
    catch_duplicate_keys: bool = False,
    float_mode: str = "float",
) -> Any:
    """``json.loads`` üzerine kurulu jiter uyumlu ayrıştırıcı."""
    if isinstance(data, (bytes, bytearray, memoryview)):
        text = bytes(data).decode("utf-8")
    else:
        text = data

    parse_float = LosslessFloat if float_mode == "lossless-float" else float

    def _dedupe(pairs):
        seen = {}
        for key, value in pairs:
            if catch_duplicate_keys and key in seen:
                raise ValueError(f"Detected duplicate key {key!r}")
            seen[key] = value
        return seen

    try:
        return json.loads(
            text,
            parse_float=parse_float,
            object_pairs_hook=_dedupe if catch_duplicate_keys else None,
        )
    except json.JSONDecodeError:
        if not partial_mode:
            raise
        # Yarım gelen parça: çağıran bir sonraki parçada yeniden deneyecek.
        return {}
